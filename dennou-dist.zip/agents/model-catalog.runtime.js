import { r as loadModelCatalog } from "../model-catalog-DrU9crvV.js";
export { loadModelCatalog };
